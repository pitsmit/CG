import { Info } from './info-functions.js';

var arr_1 = [[], []];
var arr_2 = [[], []];

const width = window.innerWidth;
const height = window.innerHeight;



function addRowHandlers(tab) {
    var table = document.getElementById(tab);
    var rows = table.getElementsByTagName("tr");
    for (i = 1; i < rows.length; i++) {
      var currentRow = table.rows[i];

      var createClickHandler1 = function(row) {
        return function() {
          row.remove();
        };
      };

      currentRow.ondblclick = createClickHandler1(currentRow);
    }
  }

addRowHandlers("multi1");
addRowHandlers("multi2");


var stage = new Konva.Stage({
  container: 'container',
  width: width,
  height: height,
});

var xAxis = new Konva.Line({
    points: [-99999999, stage.height() / 2, 999999999, stage.height() / 2],
    stroke: 'black',
    strokeWidth: 2
});
  
var yAxis = new Konva.Line({
    points: [stage.width() / 2, -999999999, stage.width() / 2, 9999999999],
    stroke: 'black',
    strokeWidth: 2
});

var layer = new Konva.Layer();
stage.add(layer);

layer.add(xAxis);
layer.add(yAxis);

for (var i = -14312; i < 14324; i+=50) {
    var hui = new Konva.Line({
        points: [i, -999999999, i, 9999999999],
        stroke: 'grey',
        strokeWidth: 1
    });

    layer.add(hui);
}


for (var i = -14312; i < 14324; i+=50) {
    var hui = new Konva.Line({
        points: [-999999999, i, 999999999, i],
        stroke: 'grey',
        strokeWidth: 1
    });

    layer.add(hui);
}


function delete_cords_of_deleted(x, y, src) {
    for (var i = 0; i < src[0].length; i++){
        if (src[0][i] == x && src[1][i] == y){
            for (var k = i; k < src[0].length - 1; k++){
                src[0][k] = src[0][k + 1];
                src[1][k] = src[1][k + 1];
            }
            src[0].pop();
            src[1].pop();
            break;
        }
    }
}


stage.on('dblclick', function() {
    var pointer = stage.getRelativePointerPosition();
    var circle1 = new Konva.Circle({
        x: pointer.x,
        y: pointer.y,
        radius: 5,
        fill: 'red',
    });
    layer.add(circle1);
    circle1.on('click', function () {
        circle1.destroy();
        delete_cords_of_deleted(pointer.x, pointer.y, arr_1);
    });
    arr_1[0].push(pointer.x);
    arr_1[1].push(pointer.y);
});


stage.on('contextmenu', function() {
    var pointer = stage.getRelativePointerPosition();
    var circle2 = new Konva.Circle({
        x: pointer.x,
        y: pointer.y,
        radius: 5,
        fill: 'green',
    });
    layer.add(circle2);
    circle2.on('click', function () {
        circle2.destroy();
        delete_cords_of_deleted(pointer.x, pointer.y, arr_2);
    });
    arr_2[0].push(pointer.x);
    arr_2[1].push(pointer.y);

    if (arr_1[0][arr_1[0].length - 1] == arr_2[0][arr_2[0].length - 1] && arr_1[1][arr_1[1].length - 1] == arr_2[1][arr_2[1].length - 1]){
        arr_1[0].pop();
        arr_1[1].pop();
    }
});


var scaleBy = 1.01;
stage.on('wheel', (e) => {
  e.evt.preventDefault();

  var oldScale = stage.scaleX();
  var pointer = stage.getPointerPosition();

  var mousePointTo = {
    x: (pointer.x - stage.x()) / oldScale,
    y: (pointer.y - stage.y()) / oldScale,
  };

  let direction = e.evt.deltaY > 0 ? -1 : 1;

  if (e.evt.ctrlKey) {
    direction = -direction;
  }

  var newScale = direction > 0 ? oldScale * scaleBy : oldScale / scaleBy;

  stage.scale({ x: newScale, y: newScale });

  var newPos = {
    x: pointer.x - mousePointTo.x * newScale,
    y: pointer.y - mousePointTo.y * newScale,
  };
  stage.position(newPos);
  stage.batchDraw();
});


const SUCCESS = 0;
const SAME_DOTS = -1;
const EMPTY_TABLE = -2;
const BAD_SYMBOLS = -3;

function addline(tab) {
    var table = document.getElementById(tab);
    var totalRowCount = table.rows.length; 
    var row = table.insertRow(totalRowCount);
    addRowHandlers(tab);

    var cell1 = row.insertCell(0);
    var cell2 = row.insertCell(1);
    cell1.innerHTML = "";
    cell2.innerHTML = "";
    cell1.height = 20;
}



function GetCellValues(tab) {
    var arr = [[], []];
    var table = document.getElementById(tab);
    for (var r = 1; r < table.rows.length; r++) {
        for (var c = 0; c < table.rows[r].cells.length; c++) {
            arr[c].push(table.rows[r].cells[c].innerHTML);
        }
    }

    return arr;
}


function update_table(tab, arr) {
    var table = document.getElementById(tab);

    for (let i = table.rows.length - 1; i > 0; i--)
        table.deleteRow(i);

    for (var i = 0; i < arr[0].length; i++){
        var id = table.rows.length;
        var row = table.insertRow(id);
        var cell1 = row.insertCell(0);
        var cell2 = row.insertCell(1);
        cell1.innerHTML = arr[0][i];
        cell2.innerHTML = arr[1][i];
    }

    addRowHandlers(tab);
}


function check_same(arr, table) {
    for (var i = 0; i < arr[0].length; i++)
        for (var j = i + 1; j < arr[0].length; j++)
            if (arr[0][i] == table[0][j] && arr[1][i] == table[1][j])
                return SAME_DOTS;
}



function update_graph(tab_arr, name, arr) {
    for (var i = 0; i < tab_arr[0].length; i++){
        var flag = 0;
        for (var j = 0; j < arr[0].length; j++) {
            if (arr[0][j] == tab_arr[0][i] && arr[1][j] == tab_arr[1][i])
                flag = 1;
        }
        if (flag == 1)
            continue;
        if (name == 'dblclick') {
            var circle11 = new Konva.Circle({
                x: tab_arr[0][i] + width / 2,
                y: height / 2 - tab_arr[1][i],
                radius: 5,
                fill: 'red',
            });
            layer.add(circle11);
            circle11.on('click', function () {
                delete_cords_of_deleted(circle11.x, circle11.y, arr);
                circle11.destroy();
            });
        }
        else if (name == 'contextmenu') {
            var circle22 = new Konva.Circle({
                x: tab_arr[0][i] + width / 2,
                y: height / 2 - tab_arr[1][i],
                radius: 5,
                fill: 'green',
            });
            layer.add(circle22);
            circle22.on('click', function () {
                delete_cords_of_deleted(circle22.x, circle22.y, arr);
                circle22.destroy();
            });
        }
    }
}



function create_circles(arr) {
    var res = [];
    for (var i = 0; i < arr[0].length; i++){
        for (var j = i + 1; j < arr[0].length; j++){
            for (var k = j + 1; k < arr[0].length; k++){
                if (!((arr[0][k] - arr[0][i]) / (arr[0][j] - arr[0][i]) == (arr[1][k] - arr[1][i]) / (arr[1][j] - arr[1][i]))){
                    var circle = [[arr[0][i], arr[1][i]], [arr[0][j], arr[1][j]], [arr[0][k], arr[1][k]]]
                    res.push(circle);
                }
            }
        }
    }
    return res;
}


function search_centeres(arr) {
    var circles_data = [];
    for (var i = 0; i < arr.length; i++){
        var p1x = arr[i][0][0];
        var p1y = arr[i][0][1];
        var p2x = arr[i][1][0];
        var p2y = arr[i][1][1];
        var p3x = arr[i][2][0];
        var p3y = arr[i][2][1];
        const m12_x = (p1x + p2x) / 2;
        const m12_y = (p1y + p2y) / 2;
        const m23_x = (p2x + p3x) / 2;
        const m23_y = (p2y + p3y) / 2;

        // Вычисляем коэффициенты наклона перпендикулярных отрезков
        const s12 = -(p2x - p1x) / (p2y - p1y + 0.0001);
        const s23 = -(p3x - p2x) / (p3y - p2y + 0.0001);

        // Вычисляем координаты центра окружности
        const centerX = (s12 * m12_x - s23 * m23_x + m23_y - m12_y) / (s12 - s23 + 0.0001);
        const centerY = s12 * (centerX - m12_x) + m12_y;

        // Вычисляем радиус окружности
        const radius = Math.sqrt((p1x - centerX) ** 2 + (p1y - centerY) ** 2);

        circles_data.push([centerX, centerY, radius]);
    }

    return circles_data;
}


function delete_spaces(arr) {
    var res = [[], []];

    for (var i = 0; i < arr.length; i++){
        for (var j = 0; j < arr[i].length; j++){
            if (arr[i][j] != '' && arr[i][j] != '<br>')
                res[i].push(arr[i][j]);
        }
    }

    return res;
}

function make_float(arr) {
    for (var i = 0; i < arr.length; i++)
        for (var j = 0; j < arr[i].length; j++)
            arr[i][j] = parseFloat(arr[i][j]);
}

function add_to_arr_canvas_cords(dest, src) {
    for (var i = 0; i < src.length; i++){
        for (var j = 0; j < src[i].length; j++){
            /*var flag = 0;
            for (var k = 0; k < dest[i].length; k++)
                if (dest[0][k] == src[0][j] + width / 2)
                if (dest[i][k] == src[i][j] + width / 2 || dest[i][k] == height / 2 - src[i][j])
                    flag = 1;
            if (flag == 1)
                continue;*/
            if (i == 0)
                dest[i].push(src[i][j] + width / 2);
            else
                dest[i].push(height / 2 - src[i][j]);
        }
    }
}

function create_new_data_for_table(src) {
    var res = [[], []];
    for (var i = 0; i < src.length; i++){
        for (var j = 0; j < src[i].length; j++){
            if (i == 0)
                res[i].push(src[i][j] - width / 2);
            else
                res[i].push(height / 2 - src[i][j]);
        }
    }
    return res;
}


function validation(tab) {
    for (var i = 0; i < tab.length; i++){
        for (var j = 0; j < tab[i].length; j++){
            if (tab[i][j] == '<br>')
                continue;
            for (var k = 0; k < tab[i][j].length; k++)
                if (!"0123456789.-".includes(tab[i][j][k]))
                    return false;
                else if (tab[i][j][0] == '.')
                    return false;
                else if (tab[i][j][tab[i][j].length - 1] == '.')
                    return false;
                else if (k != 0 && tab[i][j][k] == '-')
                    return false;
        }
    }

    return true;
}

function search_corners(centers_1, centers_2){
    var final_data = [];

    for (var i = 0; i < centers_1.length; i++){
        for (var j = 0; j < centers_2.length; j++){
            var center1_x = centers_1[i][0];
            var center1_y = centers_1[i][1];
            var center1_R = centers_1[i][2];
            var center2_x = centers_2[j][0];
            var center2_y = centers_2[j][1];
            var center2_R = centers_2[j][2];

            var k = (center2_y - center1_y) / (center2_x - center1_x);
            var b = center1_y - center1_x * k;

            var tan = k;

            var radians_on_X = Math.atan(tan);

            var degree_on_X = (180 * radians_on_X) / Math.PI;
            var result_angle = 90 - degree_on_X;

            var res_data = [[center1_x, center1_y, center1_R], [center2_x, center2_y, center2_R], result_angle];
            final_data.push(res_data);
        }
    }
    return final_data;
}



function search_min_angle(data){
    var res = [[], [], 0];
    var min_angle = data[0][2];
    for (var i = 0; i < data.length; i++){
        if (data[i][2] <= min_angle){
            res = data[i];
            min_angle = data[i][2];
        }
    }

    return res;
}


function show_res_table(data){
    var table = document.getElementById('ResTable');

    table.rows[1].cells[1].innerHTML = data[0][2].toFixed(4);
    table.rows[2].cells[1].innerHTML = data[1][2].toFixed(4);

    table.rows[1].cells[2].innerHTML = String(data[0][0].toFixed(4)) + "        " + String(data[0][1].toFixed(4));
    table.rows[2].cells[2].innerHTML = String(data[1][0].toFixed(4)) + "        " + String(data[1][1].toFixed(4));
}




function Run() {

    //console.log(arr_1);
    //console.log(arr_2);

    var table_arr_1 = GetCellValues('multi1');
    var table_arr_2 = GetCellValues('multi2');
    var new_tab_1 = delete_spaces(table_arr_1);
    var new_tab_2 = delete_spaces(table_arr_2);
    if (!validation(new_tab_1) || !validation(new_tab_2)){
        alert("Ошибка! В таблицы введены некорректные данные! Проверьте правильность ввода.");
        return -6;
    }
    make_float(new_tab_1);
    make_float(new_tab_2);

    update_graph(new_tab_1, 'dblclick', arr_1);
    update_graph(new_tab_2, 'contextmenu', arr_2);

    add_to_arr_canvas_cords(arr_1, new_tab_1);
    add_to_arr_canvas_cords(arr_2, new_tab_2);

    var final_tab_1 = create_new_data_for_table(arr_1);
    var final_tab_2 = create_new_data_for_table(arr_2);

    if (final_tab_1[0].length < 3 || final_tab_2[0].length < 3){
        alert("Ошибка! В каждом множестве должно быть минимум по 3 точки!");
        return -5;
    }

    update_table('multi1', final_tab_1);
    update_table('multi2', final_tab_2);
    
    var circle_arr_1 = create_circles(arr_1);
    var circle_arr_2 = create_circles(arr_2);

    if (circle_arr_1.length == 0 || circle_arr_2.length == 0){
        alert("Ошибка! Похоже, что точки с такими координатами не позволяют провести окружностей");
        return -7;
    }

    console.log(circle_arr_1, circle_arr_2);
    var centres_1 = search_centeres(circle_arr_1);
    var centres_2 = search_centeres(circle_arr_2);

    console.log(centres_1);
    console.log(centres_2);

    var final_pairs_circles_with_corners = search_corners(centres_1, centres_2);
    var min_angle_arr_data = search_min_angle(final_pairs_circles_with_corners);

    var group = new Konva.Group({
    });

    var ResCircle1 = new Konva.Circle({
        x: min_angle_arr_data[0][0],
        y: min_angle_arr_data[0][1],
        radius: min_angle_arr_data[0][2],
        stroke: 'red',
        strokeWidth: 2
    });

    var ResCircle2 = new Konva.Circle({
        x: min_angle_arr_data[1][0],
        y: min_angle_arr_data[1][1],
        radius: min_angle_arr_data[1][2],
        stroke: 'green',
        strokeWidth: 2
    });

    var LineBetweenCentres = new Konva.Line({
        points: [min_angle_arr_data[0][0], min_angle_arr_data[0][1], min_angle_arr_data[1][0], min_angle_arr_data[1][1]],
        stroke: 'black',
        strokeWidth: 3
    });

    var Centre1 = new Konva.Circle({
        x: min_angle_arr_data[0][0],
        y: min_angle_arr_data[0][1],
        radius: 7,
        fill: 'blue'
    });

    var Centre2 = new Konva.Circle({
        x: min_angle_arr_data[1][0],
        y: min_angle_arr_data[1][1],
        radius: 7,
        fill: 'blue'
    });

    group.add(ResCircle1);
    group.add(ResCircle2);
    group.add(LineBetweenCentres);
    group.add(Centre1);
    group.add(Centre2);
    layer.add(group);

    show_res_table(min_angle_arr_data);


    /*layer.on('click', function () {
       group.destroy();
    });
    layer.on('contextmenu', function () {
        group.destroy();
    });
     layer.on('dblclick', function () {
        group.destroy();
    });*/
}



document.getElementById("addbutton1").addEventListener("click", function(){
    addline('multi1');
}, false);
document.getElementById("addbutton2").addEventListener("click", function(){
    addline('multi2');
}, false);
document.getElementById("runner").addEventListener("click", Run);